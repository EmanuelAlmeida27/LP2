﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // BOTÃO EXECUTAR
        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[2, 3];
            string auxiliar = "";
            double nota, media, mediaGeral = 0;

            for (int i = 0; i < notas.GetLength(0); i++) // for para ler os dados
            {
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox($"Professor {j+1}, digite a nota do aluno {i+1}", "Entrada de Dados"); // input
                    if (!double.TryParse(auxiliar, out nota) || nota < 0 || nota > 10) // valida a nota
                    {
                        MessageBox.Show("Dados Inválidos!");
                        j--;
                    }
                    else
                    {
                        notas[i, j] = nota;
                    }
                }
                
            }

            for (int i=0; i < notas.GetLength(0); i++)
            {
                media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;
                mediaGeral += media / 2;
                lsbxNotas.Items.Add($"Aluno: {i + 1} | Nota Professor 1: {notas[i, 0]:F2} | Nota Professor 2: {notas[i, 1]:F2} | Nota Professor 3: {notas[i, 2]:F2} | Média: {media:F2}\n");
            }
            lsbxNotas.Items.Add("---------------------------\n");
            lsbxNotas.Items.Add($"Média Geral Alunos: {mediaGeral:F2}\n");
        }

        // BOTÃO LIMPAR
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lsbxNotas.Items.Clear();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        string classificacao, obsidade;
        public Form1()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }



        // ----- VALIDANDO TEXTBOX PESO -----
        private void txtPeso_Validated(object sender, EventArgs e)
        {
            string pesoText = txtPeso.Text.Replace('.', ',');
            if (!double.TryParse(pesoText, out peso))
            {
                MessageBox.Show("Peso inválido!");
                txtPeso.Focus();
            }
            else if (double.Parse(txtPeso.Text) <= 0)
            {
                MessageBox.Show("Peso deve ser maior que 0!");
                txtPeso.Focus();
            }
        }

        // ----- VALIDANDO TEXTBOX ALTURA -----
        private void txtAltura_Validated(object sender, EventArgs e)
        {
            string alturaText = txtAltura.Text.Replace('.', ',');
            if (!double.TryParse(alturaText, out altura))
            {
                MessageBox.Show("Altura inválida!");
                txtAltura.Focus();
            }
            else if (double.Parse(txtAltura.Text) <= 0)
            {
                MessageBox.Show("Altura deve ser maior que 0!");
                txtAltura.Focus();
            }
        }

        // ----- CALCULO BOTÃO CALCULAR -----
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Cálculo do IMC
            imc = peso / (altura * altura);
            txtImc.Text = imc.ToString("F2");
            // Classificação do IMC
            if (imc < 18.5)
            {
                classificacao = "Magreza";
                obsidade = "0";
            }
            else if (imc >= 18.5 && imc < 25)
            {
                classificacao = "Normal";
                obsidade = "0";
            }
            else if (imc >= 25 && imc < 30)
            {
                classificacao = "Sobrepeso";
                obsidade = "I";
            }
            else if (imc >= 30 && imc < 40)
            {
                classificacao = "Obesidade";
                obsidade = "II";
            }
            else
            {
                classificacao = "Obesidade Grave";
                obsidade = "III";
            }
            MessageBox.Show("Imc: " + imc.ToString("F2") + "\nClassificação: " + classificacao + "\nObesidade: " + obsidade);
        }

        // ----- BOTÃO LIMPAR -----
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
            txtImc.Clear();
        }

        // ----- BOTÃO SAIR -----
        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você realmente deseja sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}

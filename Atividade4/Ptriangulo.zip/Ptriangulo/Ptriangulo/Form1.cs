﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;
        public Form1()
        {
            InitializeComponent();
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {

        }



        // ----- VALIDAR TEXTBOX VALOR A-----
        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorA.Text, out valorA) || double.Parse(txtValorA.Text) <= 0)
            {
                MessageBox.Show("Valor inválido!");
                txtValorA.Focus();
            }
        }

        // ----- VALIDAR TEXTBOX VALOR B-----
        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorB.Text, out valorB) || double.Parse(txtValorB.Text) <= 0)
            {
                MessageBox.Show("Valor inválido!");
                txtValorB.Focus();
            }
        }
        // ----- VALIDAR TEXTBOX VALOR C-----
        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorC.Text, out valorC) || double.Parse(txtValorC.Text) <= 0)
            {
                MessageBox.Show("Valor inválido!");
                txtValorC.Focus();
            }
        }

        // ----- VALIDAR NO CLICK DO BOTÃO -----
        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (Math.Abs(valorB-valorC) < valorA && valorA < (valorB + valorC) &&
                Math.Abs(valorA - valorC) < valorB && valorB < (valorA + valorC) &&
                Math.Abs(valorA - valorB) < valorC && valorC < (valorA + valorB))
            {
                if (valorA == valorB && valorB == valorC)
                {
                    MessageBox.Show("Triângulo Equilátero");
                }
                else if (valorA == valorB || valorA == valorC || valorB == valorC)
                {
                    MessageBox.Show("Triângulo Isósceles");
                }
                else
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Valores inválidos!\nNão forma um triângulo!");
            }
        }

        // ----- BOTÃO SAIR -----
        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // ----- BOTÃO LIMPAR -----
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNum_Click(object sender, EventArgs e)
        {
            int comprimento = rchtxtFrase.Text.Length, contador = 0, contaNum = 0;
            while (contador < comprimento)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contaNum++;
                }

                contador++;
            }

            MessageBox.Show($"O texto tem {contaNum} números");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do primeiro caracter branco é {i+1}");
                    break;
                }
            }
        }

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int contaLetras = 0;
            foreach (var letra in rchtxtFrase.Text)
            {
                if (char.IsLetter(letra))
                {
                    contaLetras++;
                }
            }
            MessageBox.Show($"O texto tem {contaLetras} letras.");

        }
    }
}

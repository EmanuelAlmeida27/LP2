﻿namespace Pmatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExc1 = new System.Windows.Forms.Button();
            this.btnExc2 = new System.Windows.Forms.Button();
            this.btnExc3 = new System.Windows.Forms.Button();
            this.btnExc4 = new System.Windows.Forms.Button();
            this.btnExc5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExc1
            // 
            this.btnExc1.Location = new System.Drawing.Point(166, 43);
            this.btnExc1.Name = "btnExc1";
            this.btnExc1.Size = new System.Drawing.Size(183, 88);
            this.btnExc1.TabIndex = 0;
            this.btnExc1.Text = "Exercício 1";
            this.btnExc1.UseVisualStyleBackColor = true;
            this.btnExc1.Click += new System.EventHandler(this.btnExc1_Click);
            // 
            // btnExc2
            // 
            this.btnExc2.Location = new System.Drawing.Point(422, 43);
            this.btnExc2.Name = "btnExc2";
            this.btnExc2.Size = new System.Drawing.Size(183, 88);
            this.btnExc2.TabIndex = 1;
            this.btnExc2.Text = "Exercício 2";
            this.btnExc2.UseVisualStyleBackColor = true;
            this.btnExc2.Click += new System.EventHandler(this.btnExc2_Click);
            // 
            // btnExc3
            // 
            this.btnExc3.Location = new System.Drawing.Point(166, 177);
            this.btnExc3.Name = "btnExc3";
            this.btnExc3.Size = new System.Drawing.Size(183, 88);
            this.btnExc3.TabIndex = 2;
            this.btnExc3.Text = "Exercício 3";
            this.btnExc3.UseVisualStyleBackColor = true;
            this.btnExc3.Click += new System.EventHandler(this.btnExc3_Click);
            // 
            // btnExc4
            // 
            this.btnExc4.Location = new System.Drawing.Point(422, 177);
            this.btnExc4.Name = "btnExc4";
            this.btnExc4.Size = new System.Drawing.Size(183, 88);
            this.btnExc4.TabIndex = 3;
            this.btnExc4.Text = "Exercício 4";
            this.btnExc4.UseVisualStyleBackColor = true;
            this.btnExc4.Click += new System.EventHandler(this.btnExc4_Click);
            // 
            // btnExc5
            // 
            this.btnExc5.Location = new System.Drawing.Point(292, 308);
            this.btnExc5.Name = "btnExc5";
            this.btnExc5.Size = new System.Drawing.Size(183, 88);
            this.btnExc5.TabIndex = 4;
            this.btnExc5.Text = "Exercício 5";
            this.btnExc5.UseVisualStyleBackColor = true;
            this.btnExc5.Click += new System.EventHandler(this.btnExc5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExc5);
            this.Controls.Add(this.btnExc4);
            this.Controls.Add(this.btnExc3);
            this.Controls.Add(this.btnExc2);
            this.Controls.Add(this.btnExc1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExc1;
        private System.Windows.Forms.Button btnExc2;
        private System.Windows.Forms.Button btnExc3;
        private System.Windows.Forms.Button btnExc4;
        private System.Windows.Forms.Button btnExc5;
    }
}


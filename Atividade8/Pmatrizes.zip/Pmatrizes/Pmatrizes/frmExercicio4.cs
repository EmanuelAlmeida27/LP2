﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        // Botão Executar
        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10]; // vetor para armazenar nomes
            int[] comprimentoNomes = new int[10]; // vetor para armazenar comprimentos dos nomes
            string auxiliar = "";

            // for para ler os nomes
            for (int i = 0; i < nomes.Length; i++) 
            {
                auxiliar = Interaction.InputBox("Digite o nome", "Entrada de Dados"); // Input de dados
                if (string.IsNullOrWhiteSpace(auxiliar)) // Verificar se o nome é vazio ou somente espaço em branco
                {
                    MessageBox.Show("Nome inválido!");
                    i--; // Decrementar índice para repetir entrada
                }
                else
                {
                    nomes[i] = auxiliar; // coloca o nome no vetor
                    auxiliar = auxiliar.Replace(" ", ""); // Remover espaços em branco
                    comprimentoNomes[i] = auxiliar.Length; // Armazenar comprimento do nome
                }
            }

            lstbxExibirNomes.Items.Clear(); // Limpar ListBox antes de exibir os resultados

            // for para exibir os nomes e seus comprimentos
            for (int i = 0; i < nomes.Length; i++) 
            {
                lstbxExibirNomes.Items.Add($"O nome {nomes[i]} tem {comprimentoNomes[i]} caracteres\n");
            }
            
        }
    }
}
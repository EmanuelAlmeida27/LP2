﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Exercício 1
        private void btnExc1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20]; // Criar vetor com 20 elementos
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)  // percorrer vetor para ler dados
            {
                auxiliar = Interaction.InputBox("Digite o número: ", "Entrada de Dados"); // Input de dados
                if (!int.TryParse(auxiliar, out vetor[i])) // Verificar se é número
                {
                    MessageBox.Show("Dados Inválidos!");
                    i--; // Decrementar índice para repetir entrada
                }
            }

            Array.Reverse(vetor); // Inverter o vetor
            // vetor.Reverse(); // Outra forma de inverter o vetor

            string invertido = string.Join("\n", vetor); // Converter vetor para string
            MessageBox.Show("Vetor invertido: \n" + invertido); // Mostrar vetor invertido
        }

        // Exercício 2
        private void btnExc2_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList(); // Criar ArrayList para armazenar nomes. Pode usar {"ana", "beatriz", ...} para inicializar
            string auxiliar = "";
            nomes.Add("Ana");
            nomes.Add("André");
            nomes.Add("Beatriz");
            nomes.Add("Camila");
            nomes.Add("João");
            nomes.Add("Joana");
            nomes.Add("Otávio");
            nomes.Add("Marcelo");
            nomes.Add("Pedro");
            nomes.Add("Thais");

            nomes.Remove("Otávio");

            foreach (string nome in nomes)
            {
                auxiliar = auxiliar + "\n" + nome;
            }
            MessageBox.Show("Nomes depois de remover \"Otávio\": \n" + auxiliar);
        }

        // Exercício 3
        private void btnExc3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3]; // Criar matriz 20x3
            string auxiliar = "";
            double nota;

            for (int i = 0; i < notas.GetLength(0); i++) // Percorrer linhas
            {
                for (int j = 0; j < notas.GetLength(1); j++) // Percorrer colunas
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}: ", "Entrada de Dados"); // Input de dados
                    if (!double.TryParse(auxiliar, out nota) || nota < 0 || nota > 10) // Verificar se é número e se a nota é maior que 0 e menor que 10
                    {
                        MessageBox.Show("Dados Inválidos!");
                        j--; // Decrementar índice para repetir entrada
                    } else
                    {
                        notas[i, j] = nota; // Armazenar nota na matriz
                    }
                }

            }

            auxiliar = "";

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                auxiliar = auxiliar + $"Aluno {i+1}: Média: {(notas[i,0] + notas[i,1] + notas[i,2]) / 3:F2}\n";
            }

            MessageBox.Show(auxiliar);
        }

        // Exercício 4
        private void btnExc4_Click(object sender, EventArgs e)
        {
            // OUTRA FORMA DE ABRIR O FORMULÁRIO
            //using (var f = new frmExercicio4())
            //{
            //    f.ShowDialog();
            //}

            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront();
            } else
            {
                frmExercicio4 obj4 = new frmExercicio4();
                obj4.Show();
            }
        }

        // Exercício 5
        private void btnExc5_Click(object sender, EventArgs e)
        {
            // OUTRA FORMA DE ABRIR O FORMULÁRIO
            //using (var f = new frmExercicio5())
            //{
            //    f.ShowDialog();
            //}

            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 obj5 = new frmExercicio5();
                obj5.Show();
            }
        }
    }
}
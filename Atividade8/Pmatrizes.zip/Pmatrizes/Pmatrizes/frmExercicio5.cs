﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            // Meu RA 0030482511039
            // Ultimo digito é 9
            string[,] matriz = new string[9, 10];
            string[] gabarito = new string[] { "A", "B", "C", "D", "E", "E", "D", "C", "B", "A" };
            string auxiliar = "";


            // Leitura das respostas
            for (int i = 0; i < matriz.GetLength(0); i++) // Percorrer linhas
            {
                for (int j = 0; j < matriz.GetLength(1); j++) // Percorrer colunas
                {
                    auxiliar = Interaction.InputBox("Digite a resposta", "Entrada de Dados");
                    auxiliar = auxiliar.ToUpper(); // Converter para maiúsculo
                    if (auxiliar.Length > 1 || (auxiliar != "A"
                                             && auxiliar != "B"
                                             && auxiliar != "C"
                                             && auxiliar != "D"
                                             && auxiliar != "E"))
                    {
                        MessageBox.Show("Dado Inválido");
                        j--; // Decrementar índice para repetir entrada
                    }
                    else
                    {
                        matriz[i, j] = auxiliar;
                    }
                }

            }

            lstbxExibir.Items.Clear();
            // verificação
            for (int i = 0; i < matriz.GetLength(0); i++) 
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    if (matriz[i, j] == gabarito[j])
                    {
                        lstbxExibir.Items.Add($"O aluno {i+1} acertou a questão {j+1}. Era {gabarito[j]}, escolheu {matriz[i, j]}");
                    } else
                    {
                        lstbxExibir.Items.Add($"O aluno {i+1} errou a questão {j+1}. Era {gabarito[j]}, escolheu {matriz[i, j]}");
                    }
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; // Variáveis globais

        public Form1()
        {
            InitializeComponent();
        }


        // ----- VALIDA TEXTBOX NUMERO1 -----
        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero1.Text, out numero1)) // converte o texto do txtNumero1 para double. Se der erro, entra no if 
            {
                //MessageBox.Show("Número inválido!");
                errorProvider1.SetError(txtNumero1, "Número inválido!"); // mostra o erro no errorProvider1
                txtNumero1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtNumero1, ""); // limpa o erro do errorProvider1
            }
        }

        // ----- VALIDA TEXTBOX NUMERO2 -----
        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            //if (!double.TryParse(txtNumero2.Text, out numero2))
            //{
            //    //MessageBox.Show("Número inválido!");
            //    errorProvider2.SetError(txtNumero2, "Número inválido!");
            //    txtNumero2.Focus();
            //}
            //else
            //{
            //    errorProvider2.SetError(txtNumero2, "");
            //}
            try
            {
                errorProvider2.SetError(txtNumero2, "");
                numero2 = Convert.ToDouble(txtNumero2.Text);
            }
            catch (Exception)
            {
                errorProvider2.SetError(txtNumero2, "Número 2 inválido!");
                txtNumero2.Focus();
            }
        }

        // ----- BOTÃO LIMPAR -----
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtResultado.Clear();
            txtNumero1.Clear();
            txtNumero2.Clear();
        }

        // ----- BOTÃO SAIR -----
        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você realmente deseja sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        // ----- BOTÃO SOMAR -----
        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }

        // ----- BOTÃO SUBTRAIR -----
        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        // ----- BOTÃO MULTIPLICAR -----
        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        // ----- BOTÃO DIVIDIR -----
        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                // MessageBox.Show("Divisão por zero não é permitida!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                MessageBox.Show("Divisão por zero não é permitida!");
                txtNumero2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
                
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume; // globais
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        // ----- TEXT BOX RAIO -----
        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio) || raio <= 0) // Verifica se é texto e menor ou igual a zero
            {
                MessageBox.Show("Raio inválido!");
            }
            //else
            //{
            //    if (raio <= 0)
            //    {
            //        MessageBox.Show("Raio deve ser maior que zero!");
            //    }
            //}

        }

        

        // ----- TEXT BOX ALTURA -----
        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtAltura.Text, out altura) || altura <= 0) // Verifica se é texto e menor ou igual a zero
            {
                MessageBox.Show("Altura inválida!");
            }
        }

        

        // ----- BUTTON CALCULAR -----
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || raio <= 0) // Valida novamente
            {
                MessageBox.Show("Raio inválido!");
                txtRaio.Focus(); // Retorna o foco no Text Box Raio
            }
            else if (!Double.TryParse(txtAltura.Text, out altura) || altura <= 0) // Valida novamente
            {
                MessageBox.Show("Altura inválido!");
                txtAltura.Focus(); // Retorna o foco no Text Box Altura
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura; // Calculo
                txtVolume.Text = volume.ToString("N2"); // Mostra resultado no Text Box Volume
            }
        }

        // ----- BUTTON LIMPAR -----
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = string.Empty;
            txtVolume.Clear();
        }

        // ----- BUTTON FECHAR -----
        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}